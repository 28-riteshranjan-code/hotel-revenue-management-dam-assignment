-- Hotel Revenue Management: SQL analysis queries
-- Source database: Hotel_Revenue_Management.db
-- These queries correspond to Tasks 4.10-4.20 in the Colab notebook.
-- ADR quartiles used in Task 4.18 were calculated from the Bookings table.

-- 4.10 Retrieve and sort bookings
SELECT booking_id, adr, lead_time, adults, hotel_id
FROM Bookings
ORDER BY adr DESC
LIMIT 10;


-- 4.11 Filter bookings with WHERE, AND, OR and BETWEEN
SELECT booking_id, adr, lead_time, adults, children
FROM Bookings
WHERE adr BETWEEN 50 AND 200
  AND lead_time >= 30
  AND (adults >= 2 OR children > 0)
ORDER BY adr DESC;


-- 4.12 Filter using IN and LIKE
SELECT b.booking_id, s.market_segment, b.country, b.adr
FROM Bookings b
INNER JOIN Segments s ON b.segment_id = s.segment_id
WHERE s.market_segment IN ('Online TA', 'Offline TA/TO')
  AND s.market_segment LIKE '%TA%'
  AND b.country LIKE 'P%'
ORDER BY b.adr DESC
LIMIT 20;


-- 4.13 Handle missing values using COALESCE
SELECT COALESCE(country, 'Unknown') AS Country_Name,
       COUNT(*) AS Total_Bookings
FROM Bookings
GROUP BY COALESCE(country, 'Unknown')
ORDER BY Total_Bookings DESC;


-- 4.13 Additional check for NULL country values
SELECT COUNT(*) AS Total_Records,
       SUM(CASE WHEN country IS NULL THEN 1 ELSE 0 END) AS Missing_Country_Records
FROM Bookings;


-- 4.14 Aggregate functions COUNT, SUM, AVG, MIN and MAX
SELECT COUNT(*) AS Total_Bookings,
       SUM(adults + children + babies) AS Total_Guest_Count,
       ROUND(AVG(adr), 2) AS Average_ADR,
       ROUND(MIN(adr), 2) AS Minimum_ADR,
       ROUND(MAX(adr), 2) AS Maximum_ADR
FROM Bookings;


-- 4.15 GROUP BY and HAVING
SELECT s.market_segment,
       COUNT(*) AS Total_Bookings,
       ROUND(AVG(b.adr), 2) AS Average_ADR
FROM Bookings b
INNER JOIN Segments s ON b.segment_id = s.segment_id
GROUP BY s.market_segment
HAVING COUNT(*) >= 1000
ORDER BY Average_ADR DESC;


-- 4.16 INNER JOIN hotel and bookings
SELECT h.hotel AS Hotel_Type,
       COUNT(*) AS Total_Bookings,
       ROUND(AVG(b.adr), 2) AS Average_ADR
FROM Bookings b
INNER JOIN Hotels h ON b.hotel_id = h.hotel_id
GROUP BY h.hotel
ORDER BY Average_ADR DESC;


-- 4.17 LEFT JOIN segments and bookings
SELECT s.market_segment,
       COUNT(b.booking_id) AS Total_Bookings,
       ROUND(AVG(b.adr), 2) AS Average_ADR
FROM Segments s
LEFT JOIN Bookings b ON s.segment_id = b.segment_id
GROUP BY s.market_segment
ORDER BY Total_Bookings DESC;


-- 4.18 CASE WHEN ADR classification
SELECT CASE
         WHEN adr <= 72.0000000000 THEN 'Lower ADR Group'
         WHEN adr <= 134.0000000000 THEN 'Middle ADR Group'
         ELSE 'Upper ADR Group'
       END AS ADR_Category,
       COUNT(*) AS Total_Bookings,
       ROUND(AVG(adr), 2) AS Average_ADR
FROM Bookings
GROUP BY ADR_Category
ORDER BY Average_ADR;


-- 4.19 ADR by hotel type and market segment
SELECT h.hotel AS Hotel_Type,
       s.market_segment AS Market_Segment,
       COUNT(*) AS Total_Bookings,
       ROUND(AVG(b.adr), 2) AS Average_ADR
FROM Bookings b
INNER JOIN Hotels h ON b.hotel_id = h.hotel_id
INNER JOIN Segments s ON b.segment_id = s.segment_id
GROUP BY h.hotel, s.market_segment
ORDER BY h.hotel, Average_ADR DESC;


-- 4.20 Monthly ADR by hotel type
SELECT h.hotel AS Hotel_Type,
       b.arrival_date_year AS Arrival_Year,
       b.arrival_date_month AS Arrival_Month,
       COUNT(*) AS Total_Bookings,
       ROUND(AVG(b.adr), 2) AS Average_ADR
FROM Bookings b
INNER JOIN Hotels h ON b.hotel_id = h.hotel_id
GROUP BY h.hotel, b.arrival_date_year, b.arrival_date_month
ORDER BY b.arrival_date_year,
       CASE b.arrival_date_month
         WHEN 'January' THEN 1 WHEN 'February' THEN 2 WHEN 'March' THEN 3
         WHEN 'April' THEN 4 WHEN 'May' THEN 5 WHEN 'June' THEN 6
         WHEN 'July' THEN 7 WHEN 'August' THEN 8 WHEN 'September' THEN 9
         WHEN 'October' THEN 10 WHEN 'November' THEN 11 WHEN 'December' THEN 12
       END;

